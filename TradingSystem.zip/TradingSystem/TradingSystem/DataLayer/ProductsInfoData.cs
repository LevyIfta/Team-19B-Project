﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingSystem.ServiceLayer
{
<<<<<<< HEAD:TradingSystem/TradingSystem/DataLayer/ProductsInfoData.cs
    class ProductsInfoData
    {
        public static ICollection<ProductInfoData> productsInfo = new LinkedList<ProductInfoData>();
=======
    class ProductController
    {

>>>>>>> ShauliTasks:TradingSystem/TradingSystem/ServiceLayer/ProductController.cs
    }
}
