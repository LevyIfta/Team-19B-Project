﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingSystem.BuissnessLayer.User.Permmisions
{
    public enum PersmissionsTypes
    {
        AddProduct,
        EditManagerPermissions,
        EditProduct,
        GetInfoEmployees,
        GetPurchaseHistory,
        HireNewStoreManager,
        HireNewStoreOwner,
        RemoveManager,
        RemoveProduct
    }
}
